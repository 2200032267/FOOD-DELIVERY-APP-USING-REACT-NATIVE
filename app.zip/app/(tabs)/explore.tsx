import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Pressable,
  Dimensions,
  Animated,
  FlatList,
  StatusBar,
  ListRenderItem,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';

const { width, height } = Dimensions.get('window');

// Type definitions
type Category = {
  id: string;
  name: string;
  emoji: string;
  color: string;
};

type TopPick = {
  id: string;
  name: string;
  restaurant: string;
  price: string;
  rating: number;
  time: string;
  image: string;
};

type Restaurant = {
  id: string;
  name: string;
  cuisine: string;
  rating: number;
  time: string;
  offer: string;
  image: string;
};

type Offer = {
  id: string;
  title: string;
  subtitle: string;
  color: string[];
};

const categories: Category[] = [
  { id: '1', name: 'Pizza', emoji: '🍕', color: '#ff6b6b' },
  { id: '2', name: 'Burgers', emoji: '🍔', color: '#4ecdc4' },
  { id: '3', name: 'Salads', emoji: '🥗', color: '#45b7d1' },
  { id: '4', name: 'Desserts', emoji: '🍰', color: '#f9ca24' },
  { id: '5', name: 'Asian', emoji: '🍱', color: '#f0932b' },
  { id: '6', name: 'Beverages', emoji: '☕', color: '#eb4d4b' },
  { id: '7', name: 'Snacks', emoji: '🍿', color: '#6c5ce7' },
  { id: '8', name: 'Indian', emoji: '🍛', color: '#a29bfe' },
];

const topPicks: TopPick[] = [
  {
    id: '1',
    name: 'Chicken Biryani',
    restaurant: 'Biryani House',
    price: '₹299',
    rating: 4.8,
    time: '25 mins',
    image: 'https://images.unsplash.com/photo-1563379091339-03246963d51c?w=300&h=200&fit=crop',
  },
  {
    id: '2',
    name: 'Margherita Pizza',
    restaurant: 'Pizza Corner',
    price: '₹349',
    rating: 4.6,
    time: '30 mins',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=300&h=200&fit=crop',
  },
  {
    id: '3',
    name: 'Burger Deluxe',
    restaurant: 'Burger King',
    price: '₹199',
    rating: 4.5,
    time: '20 mins',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&h=200&fit=crop',
  },
];

const featuredRestaurants: Restaurant[] = [
  {
    id: '1',
    name: 'KFC',
    cuisine: 'Fast Food',
    rating: 4.7,
    time: '25-35 mins',
    offer: 'Free Delivery',
    image: 'https://images.unsplash.com/photo-1513639776629-7b61b0ac49cb?w=300&h=200&fit=crop',
  },
  {
    id: '2',
    name: "Domino's Pizza",
    cuisine: 'Pizza, Italian',
    rating: 4.5,
    time: '30-40 mins',
    offer: '30% OFF',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=300&h=200&fit=crop',
  },
  {
    id: '3',
    name: 'Subway',
    cuisine: 'Healthy, Sandwiches',
    rating: 4.6,
    time: '20-30 mins',
    offer: 'Buy 1 Get 1',
    image: 'https://images.unsplash.com/photo-1555072956-7758afb20e8f?w=300&h=200&fit=crop',
  },
];

const offers: Offer[] = [
  {
    id: '1',
    title: '50% OFF',
    subtitle: 'On your first order',
    color: ['#ff6b6b', '#ee4d4d'],
  },
  {
    id: '2',
    title: 'Free Delivery',
    subtitle: 'Above ₹199',
    color: ['#4ecdc4', '#44a08d'],
  },
  {
    id: '3',
    title: 'Combo Meals',
    subtitle: 'Starting ₹99',
    color: ['#f9ca24', '#f39c12'],
  },
];

export default function ExploreScreen() {
  const [searchText, setSearchText] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('All');
  
  // Animation refs
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const searchAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Initial animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(searchAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const renderCategoryItem: ListRenderItem<Category> = ({ item, index }) => (
    <Animated.View
      style={[
        styles.categoryItem,
        {
          backgroundColor: item.color,
          opacity: fadeAnim,
          transform: [
            {
              translateY: slideAnim.interpolate({
                inputRange: [0, 50],
                outputRange: [0, 50 + index * 10],
              }),
            },
            { scale: scaleAnim },
          ],
        },
      ]}
    >
      <Pressable
        style={styles.categoryPressable}
        onPress={() => console.log('Category pressed:', item.name)}
      >
        <Text style={styles.categoryEmoji}>{item.emoji}</Text>
        <Text style={styles.categoryName}>{item.name}</Text>
      </Pressable>
    </Animated.View>
  );

  const renderTopPickItem: ListRenderItem<TopPick> = ({ item, index }) => (
    <Animated.View
      style={[
        styles.topPickCard,
        {
          opacity: fadeAnim,
          transform: [
            {
              translateX: slideAnim.interpolate({
                inputRange: [0, 50],
                outputRange: [0, 30 + index * 10],
              }),
            },
          ],
        },
      ]}
    >
      <Image source={{ uri: item.image }} style={styles.topPickImage} />
      <LinearGradient
        colors={['transparent', 'rgba(0,0,0,0.8)']}
        style={styles.topPickGradient}
      >
        <View style={styles.topPickInfo}>
          <Text style={styles.topPickName}>{item.name}</Text>
          <Text style={styles.topPickRestaurant}>{item.restaurant}</Text>
          <View style={styles.topPickDetails}>
            <View style={styles.ratingContainer}>
              <Ionicons name="star" size={12} color="#ffd700" />
              <Text style={styles.ratingText}>{item.rating}</Text>
            </View>
            <Text style={styles.timeText}>{item.time}</Text>
            <Text style={styles.priceText}>{item.price}</Text>
          </View>
        </View>
      </LinearGradient>
    </Animated.View>
  );

  const renderRestaurantItem: ListRenderItem<Restaurant> = ({ item, index }) => (
    <Animated.View
      style={[
        styles.restaurantCard,
        {
          opacity: fadeAnim,
          transform: [
            {
              translateY: slideAnim.interpolate({
                inputRange: [0, 50],
                outputRange: [0, 20 + index * 5],
              }),
            },
          ],
        },
      ]}
    >
      <Image source={{ uri: item.image }} style={styles.restaurantImage} />
      <View style={styles.restaurantInfo}>
        <View style={styles.restaurantHeader}>
          <Text style={styles.restaurantName}>{item.name}</Text>
          <View style={styles.offerBadge}>
            <Text style={styles.offerText}>{item.offer}</Text>
          </View>
        </View>
        <Text style={styles.cuisineText}>{item.cuisine}</Text>
        <View style={styles.restaurantDetails}>
          <View style={styles.ratingContainer}>
            <Ionicons name="star" size={14} color="#ffd700" />
            <Text style={styles.ratingText}>{item.rating}</Text>
          </View>
          <View style={styles.timeContainer}>
            <Ionicons name="time-outline" size={14} color="#666" />
            <Text style={styles.timeText}>{item.time}</Text>
          </View>
        </View>
      </View>
    </Animated.View>
  );

  const renderOfferItem: ListRenderItem<Offer> = ({ item, index }) => (
    <Animated.View
      style={[
        styles.offerCard,
        {
          opacity: fadeAnim,
          transform: [
            {
              scale: scaleAnim.interpolate({
                inputRange: [0.9, 1],
                outputRange: [0.9 + index * 0.02, 1],
              }),
            },
          ],
        },
      ]}
    >
<LinearGradient 
  colors={['#FF0000', '#00FF00'] as const} 
  style={styles.offerGradient}
>
        <Text style={styles.offerTitle}>{item.title}</Text>
        <Text style={styles.offerSubtitle}>{item.subtitle}</Text>
        <Ionicons name="arrow-forward" size={20} color="#fff" />
      </LinearGradient>
    </Animated.View>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#6366f1" />
      
      {/* Header */}
      <LinearGradient
        colors={['#6366f1', '#8b5cf6']}
        style={styles.header}
      >
        <Animated.View
          style={[
            styles.headerContent,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.locationContainer}>
            <Ionicons name="location-outline" size={20} color="#fff" />
            <Text style={styles.locationText}>Vijayawada, AP</Text>
            <Ionicons name="chevron-down" size={16} color="#fff" />
          </View>
          
          <Animated.View
            style={[
              styles.searchContainer,
              {
                opacity: searchAnim,
                transform: [{ scale: searchAnim }],
              },
            ]}
          >
            <Ionicons name="search-outline" size={20} color="#666" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search for dishes, restaurants..."
              placeholderTextColor="#999"
              value={searchText}
              onChangeText={setSearchText}
            />
            <Pressable style={styles.filterButton}>
              <Ionicons name="options-outline" size={20} color="#6366f1" />
            </Pressable>
          </Animated.View>
        </Animated.View>
      </LinearGradient>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Limited-Time Offers */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🔥 Limited-Time Offers</Text>
          <FlatList
            data={offers}
            renderItem={renderOfferItem}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.offersContainer}
          />
        </View>

        {/* Food Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🍽️ Whats on your mind?</Text>
          <FlatList
            data={categories}
            renderItem={renderCategoryItem}
            keyExtractor={(item) => item.id}
            numColumns={4}
            scrollEnabled={false}
            contentContainerStyle={styles.categoriesGrid}
          />
        </View>

        {/* Top Picks */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>⭐ Top Picks Near You</Text>
            <Pressable>
              <Text style={styles.seeAllText}>See All</Text>
            </Pressable>
          </View>
          <FlatList
            data={topPicks}
            renderItem={renderTopPickItem}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.topPicksContainer}
          />
        </View>

        {/* Featured Restaurants */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>🏪 Featured Restaurants</Text>
            <Pressable>
              <Text style={styles.seeAllText}>See All</Text>
            </Pressable>
          </View>
          <FlatList
            data={featuredRestaurants}
            renderItem={renderRestaurantItem}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
          />
        </View>

        {/* New Arrivals */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>✨ New Arrivals</Text>
          <View style={styles.newArrivalsContainer}>
            <Animated.View
              style={[
                styles.newArrivalCard,
                {
                  opacity: fadeAnim,
                  transform: [{ scale: scaleAnim }],
                },
              ]}
            >
              <LinearGradient
                colors={['#667eea', '#764ba2']}
                style={styles.newArrivalGradient}
              >
                <Text style={styles.newArrivalTitle}>McDonalds</Text>
                <Text style={styles.newArrivalSubtitle}>Now delivering in your area!</Text>
                <Pressable style={styles.exploreButton}>
                  <Text style={styles.exploreButtonText}>Explore Menu</Text>
                </Pressable>
              </LinearGradient>
            </Animated.View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    height: 200,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerContent: {
    gap: 16,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  locationText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  filterButton: {
    padding: 4,
  },
  content: {
    flex: 1,
  },
  section: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1f2937',
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  seeAllText: {
    color: '#6366f1',
    fontSize: 14,
    fontWeight: '600',
  },
  offersContainer: {
    paddingHorizontal: 20,
    gap: 12,
  },
  offerCard: {
    width: width * 0.7,
    height: 100,
    borderRadius: 16,
    overflow: 'hidden',
  },
  offerGradient: {
    flex: 1,
    padding: 20,
    justifyContent: 'space-between',
  },
  offerTitle: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  offerSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
  },
  categoriesGrid: {
    paddingHorizontal: 20,
    gap: 16,
  },
  categoryItem: {
    flex: 1,
    aspectRatio: 1,
    borderRadius: 16,
    margin: 4,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  categoryPressable: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  categoryEmoji: {
    fontSize: 32,
  },
  categoryName: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  topPicksContainer: {
    paddingHorizontal: 20,
    gap: 16,
  },
  topPickCard: {
    width: width * 0.6,
    height: 200,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
  },
  topPickImage: {
    width: '100%',
    height: '100%',
  },
  topPickGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '60%',
    justifyContent: 'flex-end',
  },
  topPickInfo: {
    padding: 16,
  },
  topPickName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  topPickRestaurant: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    marginBottom: 8,
  },
  topPickDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  timeText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 12,
  },
  priceText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  restaurantCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 16,
    marginHorizontal: 20,
    marginBottom: 16,
    padding: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  restaurantImage: {
    width: 80,
    height: 80,
    borderRadius: 12,
  },
  restaurantInfo: {
    flex: 1,
    marginLeft: 16,
  },
  restaurantHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  restaurantName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
  },
  offerBadge: {
    backgroundColor: '#10b981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  offerText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  cuisineText: {
    color: '#6b7280',
    fontSize: 14,
    marginBottom: 8,
  },
  restaurantDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  newArrivalsContainer: {
    paddingHorizontal: 20,
  },
  newArrivalCard: {
    height: 120,
    borderRadius: 16,
    overflow: 'hidden',
  },
  newArrivalGradient: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  newArrivalTitle: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  newArrivalSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    marginBottom: 12,
  },
  exploreButton: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  exploreButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});